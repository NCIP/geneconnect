GeneConnect caGRID Data Service Client:
===================================================
This build script used to execute the client which queries on GeneConnect Data Service deployed 
at URL http://128.252.178.222:8080/wsrf/services/cagrid/GeneConnect.

Along with ANT script, the sample CQL queries are provided which is located at directory "./cql/query/".
This directory contains following XML file:

Simple_Search_CQL.xml	- Get UniGene,Ensembl Transcript and Ensembl Peptide as ouput data source given 
			  Entrez Gene ID = 1958.

With_Confidence.xml	- Get UniGene,Ensembl Transcript and Ensembl Peptide as ouput data source given 
			  Entrez Gene ID = 1958 AND Confidence Score >= 0.3.

With_Frequency.xml	- Get UniGene,Ensembl Transcript and Ensembl Peptide as ouput data source given 
			  Entrez Gene ID = 1958 AND Frequency for UniGene >= 0.3.

With_ONT.xml		- Get UniGene,Ensembl Transcript and Ensembl Peptide as ouput data source given 
			  Entrez Gene ID = 1958 AND  ONT selected as UniGene->DIRECT->Entrez Gene->
			  RefSeq mRNA->INFERRED->Ensembl Transcript->DIRECT->Ensembl Protein.

Advanced_Search.xml	- Get UniGene,Ensembl Transcript and Ensembl Peptide as ouput data source given 
			  Entrez Gene ID = 1958 AND  ONT selected as UniGene->DIRECT->Entrez Gene->
			  RefSeq mRNA->INFERRED->Ensembl Transcript->DIRECT->Ensembl Protein 
			  AND Frequency for UniGene >= 0.3.





Prerequisits:
=======================================
Globus 4.0 installed and GLOBUS_LOCATION environment variable defined.


To Run the Client:
=======================================
The targets in this script honor the following parameters:

ant clientHelp 
	Displays the usage of script.

ant runSimpleSearch 
	Executes the CQL "./cql/query/Simple_Search_CQL.xml" and writes the output as 
	XML file in "./cql/result/Simple_Search_CQL.xml" .

ant runWithConf
	Executes the CQL "./cql/query/With_Confidence.xml" and writes the output as 
	XML file in "./cql/result/With_Confidence_Result.xml" .

ant runWithFreq
	Executes the CQL "./cql/query/With_Frequency.xml" and writes the output as 
	XML file in "./cql/result/With_Frequency_Result.xml" .

ant runSearchWithONT
	Executes the CQL "./cql/query/With_ONT.xml" and writes the output as 
	XML file in "./cql/result/With_ONT_Result.xml" .

ant runAdvancedSearch
	Executes the CQL "./cql/query/Advanced_Search.xml" and writes the output as 
	XML file in "./cql/result/Advanced_Search_Result.xml" .

 ===============================================================================