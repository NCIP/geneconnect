cd ParserScripts
perl uniprot_refseq.pl $1 $2
