cd ParserScripts
perl uniprot_genbank.pl $1 $2
