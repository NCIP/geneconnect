cd ParserScripts
perl ensembl_parser.pl $1 $2
