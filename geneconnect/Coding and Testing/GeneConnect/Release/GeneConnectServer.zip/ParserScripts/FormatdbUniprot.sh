cd ParserScripts
perl FormatdbUniprot.pl $1 $2
