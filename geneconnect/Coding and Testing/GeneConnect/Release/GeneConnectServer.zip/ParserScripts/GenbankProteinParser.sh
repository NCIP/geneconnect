cd ParserScripts
perl gbankprotein.pl $1 $2
