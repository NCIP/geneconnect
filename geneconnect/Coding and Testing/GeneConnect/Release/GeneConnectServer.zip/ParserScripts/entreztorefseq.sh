cd ParserScripts
perl entrez_refseq.pl $1 $2
