cd ParserScripts
perl FormatdbRefSeqmRNA.pl $1 $2
