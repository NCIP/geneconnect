package edu.wustl.geneconnect.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class GeneConnectImpl extends GeneConnectImplBase {

	
	public GeneConnectImpl() throws RemoteException {
		super();
	}
	
}

