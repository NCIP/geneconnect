cd  ./ParserScripts
perl FormatdbRefSeqProt.pl $1 $2
