cd  ./ParserScripts
perl GenbankProteinParser.pl $1 $2
