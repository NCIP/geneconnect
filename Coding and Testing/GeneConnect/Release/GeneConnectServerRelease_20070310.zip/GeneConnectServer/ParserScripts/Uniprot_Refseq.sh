cd  ./ParserScripts
perl Uniprot_Refseq.pl $1 $2
