cd  ./ParserScripts
perl FormatdbEnsemblProt.pl $1 $2
 
