cd ParserScripts
perl FormatdbEnsemblTrans.pl $1 $2
