cd ParserScripts
perl Uniprot_Genbank.pl $1 $2
