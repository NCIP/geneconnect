cd ParserScripts
perl GenbankmRNAParser.pl $1 $2
