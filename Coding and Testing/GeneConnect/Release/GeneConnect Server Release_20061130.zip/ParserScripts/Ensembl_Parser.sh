cd ParserScripts
perl Ensembl_Parser.pl $1 $2
