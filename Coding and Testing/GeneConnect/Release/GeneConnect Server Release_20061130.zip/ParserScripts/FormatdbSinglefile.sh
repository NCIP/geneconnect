cd ParserScripts
perl FormatSinglefile.pl $1 $2
