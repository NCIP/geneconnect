cd ParserScripts
perl Entrez_Refseq.pl $1 $2
